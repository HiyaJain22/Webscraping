#include<stdio.h>
#define N 5
int MatrixChain(int p[],int n)
{
    int m[n][n];
    for( int i=1;i<n;i++)
    {
        m[i][i]=0;
    }
    for(int l=2; l<n; l++)
    {
        for(int i=1;i<n-l+1;i++)
        {
            int j=i+l-1;
            m[i][j]=9999;
            for(int k=i;k<=j-1;k++)
            {
                int q=m[i][k]+m[k+1][j]+p[i-1]*p[k]*p[j];
                if(q<m[i][j])
                    m[i][j]=q;
            }
        }
    }
    return m[1][n-1];
}
int main()
{
    int arr[]={1,5,4,3,2,1};
    int size=sizeof(arr)/sizeof(arr[0]);
    printf("%d",MatrixChain(arr,size));
    return 0;
}

